export interface Vocabulary {
  word: string;
  meaning: string;
  partOfSpeech: string;
  synonyms?: string[];
  antonyms?: string[];
}

export interface SentenceAnalysis {
  original: string;
  translation: string;
  highlighted: string; // HTML string with <span> tags for syntax
  grammarNotes: string[];
}

export interface AnalysisSummary {
  topic: string;
  titleEn: string;
  titleKo: string;
  flow: string[];
}

export interface ExamInsight {
  keywords: string[];
  mainSentenceIndex: number;
  checkpoints: {
    type: 'Grammar' | 'Vocabulary' | 'Logic' | 'Content';
    point: string;
    explanation: string;
    importance: number; // 1 to 5 stars
  }[];
}

export interface AnalysisResult {
  sentences: SentenceAnalysis[];
  vocabulary: Vocabulary[];
  summary: AnalysisSummary;
  examInsights: ExamInsight; // New feature
  stats: {
    wordCount: number;
    sentenceCount: number;
    difficultyLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  };
}

export type ThemeColor = 'pink' | 'blue' | 'green' | 'slate';

export interface DisplayOptions {
  showTranslation: boolean;
  showGrammar: boolean;
  showVocabulary: boolean;
  showSummary: boolean;
  showBlockView: boolean;
  showExamInsights: boolean; // New toggle
}

export interface AppState {
  inputText: string;
  instituteName: string;
  questionId: string;
  isAnalyzing: boolean;
  result: AnalysisResult | null;
  activeTab: 'input' | 'options' | 'api';
  customApiKey: string;
  theme: ThemeColor;
  displayOptions: DisplayOptions;
}