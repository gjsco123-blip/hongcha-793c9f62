import React, { useState } from 'react';
import InputPanel from './components/InputPanel';
import PreviewPanel from './components/PreviewPanel';
import { AppState, AnalysisResult } from './types';
import { analyzeText } from './services/geminiService';
import { Layers } from 'lucide-react';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>({
    inputText: '',
    instituteName: '',
    questionId: '',
    isAnalyzing: false,
    result: null,
    activeTab: 'input',
    customApiKey: '',
    // Defaults
    theme: 'pink',
    displayOptions: {
        showTranslation: true,
        showGrammar: true,
        showVocabulary: true,
        showSummary: true,
        showBlockView: false, // Default to underline view
        showExamInsights: true // Default to true for new feature
    }
  });

  const handleStateChange = (updates: Partial<AppState>) => {
    setAppState((prev) => ({ ...prev, ...updates }));
  };

  const handleAnalyze = async () => {
    if (!appState.inputText) return;

    handleStateChange({ isAnalyzing: true });
    
    try {
      const result: AnalysisResult = await analyzeText(
          appState.inputText, 
          appState.customApiKey
      );
      handleStateChange({ result, isAnalyzing: false });
    } catch (error: any) {
      console.error("Analysis Failed", error);
      
      let errorMessage = "분석 중 오류가 발생했습니다. API 키를 확인하거나 잠시 후 다시 시도해주세요.";
      
      // Check for specific API Quota errors (429 or RESOURCE_EXHAUSTED)
      const errorStr = JSON.stringify(error);
      if (
          errorStr.includes('429') || 
          errorStr.includes('RESOURCE_EXHAUSTED') || 
          error?.status === 429 || 
          error?.status === 'RESOURCE_EXHAUSTED'
      ) {
          errorMessage = "API 사용량이 초과되었습니다 (Quota Exceeded). 잠시 후 다시 시도하거나, 다른 Google Cloud 프로젝트의 API 키를 사용해주세요.";
      }

      alert(errorMessage);
      handleStateChange({ isAnalyzing: false });
    }
  };

  const themeBadges = {
      pink: 'bg-pink-50 border-pink-100 text-pink-600',
      blue: 'bg-blue-50 border-blue-100 text-blue-600',
      green: 'bg-emerald-50 border-emerald-100 text-emerald-600',
      slate: 'bg-slate-100 border-slate-200 text-slate-600'
  };

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 text-slate-900 overflow-hidden">
      {/* Header */}
      <header className="h-16 flex items-center justify-between px-6 bg-white border-b border-slate-200 shadow-sm z-20 shrink-0">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg shadow-lg ${appState.theme === 'slate' ? 'bg-slate-700 shadow-slate-300' : `bg-gradient-to-br from-${appState.theme}-400 to-${appState.theme}-500 shadow-${appState.theme}-200`}`}>
            <Layers size={20} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight text-slate-800">SyntaxFlow Studio <span className={`text-xs font-normal px-1.5 py-0.5 rounded ml-2 border ${themeBadges[appState.theme]}`}>Pro Edition</span></h1>
            <p className="text-[10px] text-slate-500 font-medium tracking-wider uppercase">Educators English Visualization</p>
          </div>
        </div>
        
        {/* Header Right */}
        <div className="flex items-center gap-4">
             <div className={`text-xs font-medium px-3 py-1 rounded-full border ${themeBadges[appState.theme]}`}>
                Premium Edition
             </div>
        </div>
      </header>

      {/* Main Layout */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left: Input Panel */}
        <aside className="w-[400px] shrink-0 h-full z-10 shadow-xl shadow-slate-200/50 bg-white">
          <InputPanel 
            state={appState} 
            onStateChange={handleStateChange}
            onAnalyze={handleAnalyze} 
          />
        </aside>

        {/* Right: Preview Panel */}
        <section className="flex-1 h-full relative bg-slate-100">
          <PreviewPanel state={appState} />
        </section>
      </main>
    </div>
  );
};

export default App;