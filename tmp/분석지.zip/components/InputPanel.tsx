import React from 'react';
import { AppState, ThemeColor } from '../types';
import { Type, FileText, Settings, Key, Layout, Palette, ToggleLeft, ToggleRight, Hash, Box, Lightbulb } from 'lucide-react';

interface InputPanelProps {
  state: AppState;
  onStateChange: (updates: Partial<AppState>) => void;
  onAnalyze: () => void;
}

const InputPanel: React.FC<InputPanelProps> = ({ state, onStateChange, onAnalyze }) => {
  // Themes configuration
  const themes: { id: ThemeColor; name: string; color: string }[] = [
      { id: 'pink', name: 'Coral Pink', color: 'bg-pink-500' },
      { id: 'blue', name: 'Sky Blue', color: 'bg-blue-500' },
      { id: 'green', name: 'Eco Green', color: 'bg-emerald-500' },
      { id: 'slate', name: 'Grayscale', color: 'bg-slate-600' },
  ];

  const ThemeSelector = () => (
      <div className="flex gap-3">
          {themes.map((t) => (
              <button
                  key={t.id}
                  onClick={() => onStateChange({ theme: t.id })}
                  className={`w-8 h-8 rounded-full ${t.color} border-2 transition-all ${state.theme === t.id ? 'border-slate-800 scale-110 shadow-md' : 'border-transparent opacity-70 hover:opacity-100'}`}
                  title={t.name}
              />
          ))}
      </div>
  );

  const ToggleItem = ({ label, value, onChange, icon }: { label: string, value: boolean, onChange: () => void, icon?: React.ReactNode }) => (
      <div className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg hover:border-slate-300 transition-colors">
          <span className="text-sm text-slate-600 font-medium flex items-center gap-2">
            {icon}
            {label}
          </span>
          <button onClick={onChange} className={`transition-colors ${value ? 'text-pink-500' : 'text-slate-300'}`}>
              {value ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
          </button>
      </div>
  );

  return (
    <div className="flex flex-col h-full border-r border-slate-200 bg-white">
      {/* Tab Navigation */}
      <div className="flex border-b border-slate-200 bg-slate-50/50">
        <button
          onClick={() => onStateChange({ activeTab: 'input' })}
          className={`flex-1 py-3 px-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
            state.activeTab === 'input' ? 'text-pink-600 border-b-2 border-pink-500 bg-white' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <FileText size={16} /> 입력
        </button>
        <button
          onClick={() => onStateChange({ activeTab: 'options' })}
          className={`flex-1 py-3 px-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
            state.activeTab === 'options' ? 'text-pink-600 border-b-2 border-pink-500 bg-white' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Settings size={16} /> 옵션
        </button>
        <button
           onClick={() => onStateChange({ activeTab: 'api' })}
           className={`flex-1 py-3 px-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
            state.activeTab === 'api' ? 'text-pink-600 border-b-2 border-pink-500 bg-white' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Key size={16} /> API / 번호
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {state.activeTab === 'input' && (
          <>
            <div className="space-y-2 h-full flex flex-col">
              <label className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <Type size={14} className="text-pink-400" /> 영어 텍스트 입력
              </label>
              <textarea
                value={state.inputText}
                onChange={(e) => onStateChange({ inputText: e.target.value })}
                placeholder="지문을 붙여넣으세요..."
                className="w-full flex-1 min-h-[400px] bg-white border border-slate-200 rounded-lg p-4 text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-200 focus:border-pink-400 resize-none font-mono text-sm shadow-sm"
              />
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-600 flex items-center gap-2">
                        <Hash size={14} className="text-pink-400" /> 문항 번호 (Index)
                    </label>
                    <input 
                        type="text" 
                        value={state.questionId} 
                        onChange={(e) => onStateChange({ questionId: e.target.value })} 
                        placeholder="예: 31번, 2024년 3월 29번"
                        autoComplete="off"
                        className="w-full bg-white border border-slate-200 rounded-lg px-4 py-2 text-slate-700 focus:ring-2 focus:ring-pink-200 outline-none shadow-sm" 
                    />
                </div>
            </div>
          </>
        )}

        {state.activeTab === 'options' && (
            <div className="space-y-6">
                 <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <label className="text-sm font-medium text-slate-600 flex items-center gap-2 mb-3">
                        <Palette size={16} className="text-pink-400" /> 테마 색상 (Theme)
                    </label>
                    <ThemeSelector />
                </div>

                <div className="space-y-3">
                     <label className="text-sm font-medium text-slate-600 flex items-center gap-2">
                        <Layout size={16} className="text-pink-400" /> 표시 옵션
                    </label>
                    <div className="space-y-2 bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <ToggleItem label="구문 블록 모드 (Block View)" icon={<Box size={14} className="text-emerald-500"/>} value={state.displayOptions.showBlockView} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showBlockView: !state.displayOptions.showBlockView }})} />
                        <div className="h-px bg-slate-200 my-2"></div>
                        <ToggleItem label="출제 포인트 (Exam Check)" icon={<Lightbulb size={14} className="text-amber-500"/>} value={state.displayOptions.showExamInsights} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showExamInsights: !state.displayOptions.showExamInsights }})} />
                        <div className="h-px bg-slate-200 my-2"></div>
                        <ToggleItem label="한글 해석 표시" value={state.displayOptions.showTranslation} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showTranslation: !state.displayOptions.showTranslation }})} />
                        <ToggleItem label="어법 분석 표시" value={state.displayOptions.showGrammar} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showGrammar: !state.displayOptions.showGrammar }})} />
                        <ToggleItem label="어휘 주석 표시" value={state.displayOptions.showVocabulary} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showVocabulary: !state.displayOptions.showVocabulary }})} />
                        <ToggleItem label="구조/요약 표시" value={state.displayOptions.showSummary} onChange={() => onStateChange({ displayOptions: { ...state.displayOptions, showSummary: !state.displayOptions.showSummary }})} />
                    </div>
                </div>
            </div>
        )}
        
         {state.activeTab === 'api' && (
            <div className="space-y-6">
                 <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100">
                    <h4 className="text-emerald-700 text-sm font-bold mb-2">🚀 최적화 완료</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                        모델: <strong>Gemini 3 Flash</strong><br/>
                        사고 레벨: <strong>High (Enabled)</strong><br/>
                        복잡한 어법도 정교하게 분석합니다.
                    </p>
                </div>

                 <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-600 flex items-center gap-2">
                        <Key size={14} className="text-pink-400" /> Gemini API Key
                    </label>
                    <input type="password" value={state.customApiKey} onChange={(e) => onStateChange({ customApiKey: e.target.value })} placeholder="기본 키 사용 (입력 시 사용자 키 우선)" className="w-full bg-white border border-slate-200 rounded-lg px-4 py-3 text-slate-700 focus:ring-2 focus:ring-pink-200 outline-none text-sm font-mono shadow-sm" />
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-600 flex items-center gap-2">
                        <Hash size={14} className="text-pink-400" /> 문항 번호 설정
                    </label>
                    <input 
                        type="text" 
                        value={state.questionId} 
                        onChange={(e) => onStateChange({ questionId: e.target.value })} 
                        placeholder="예: 31번, 2024년 3월 29번"
                        autoComplete="off"
                        className="w-full bg-white border border-slate-200 rounded-lg px-4 py-2 text-slate-700 focus:ring-2 focus:ring-pink-200 outline-none shadow-sm" 
                    />
                </div>
            </div>
        )}
      </div>

      <div className="p-6 border-t border-slate-200 bg-slate-50/50">
        <button
          onClick={onAnalyze}
          disabled={!state.inputText || state.isAnalyzing}
          className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-all
            ${!state.inputText || state.isAnalyzing ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-pink-400 to-pink-500 hover:from-pink-500 hover:to-pink-600 text-white shadow-pink-200 transform hover:-translate-y-0.5'}`}
        >
          {state.isAnalyzing ? "분석 중..." : "시각화 생성"}
        </button>
      </div>
    </div>
  );
};

export default InputPanel;