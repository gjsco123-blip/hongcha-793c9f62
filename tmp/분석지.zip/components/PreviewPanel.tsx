import React, { useState, useEffect, useRef } from 'react';
import { AppState, ThemeColor } from '../types';
import { FileText, Download, BookOpen, ListOrdered, ArrowDown, AlignLeft, Lightbulb, CheckCircle2, Star, FileCheck } from 'lucide-react';

// Declare html2pdf for TypeScript since it's loaded via script tag
declare var html2pdf: any;

interface PreviewPanelProps {
  state: AppState;
}

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ state }) => {
  const [contextMenu, setContextMenu] = useState<ContextMenuState>({ visible: false, x: 0, y: 0 });
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const printableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = () => setContextMenu({ ...contextMenu, visible: false });
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, [contextMenu]);

  const THEME_CONFIG: Record<ThemeColor, { hex: string, bg: string, text: string, border: string, badge: string, flowLine: string }> = {
      pink: { hex: '#f472b6', bg: 'bg-pink-50', text: 'text-pink-600', border: 'border-pink-200', badge: 'bg-pink-400', flowLine: 'border-pink-300' },
      blue: { hex: '#60a5fa', bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200', badge: 'bg-blue-400', flowLine: 'border-blue-300' },
      green: { hex: '#34d399', bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200', badge: 'bg-emerald-400', flowLine: 'border-emerald-300' },
      slate: { hex: '#94a3b8', bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300', badge: 'bg-slate-500', flowLine: 'border-slate-300' },
  };

  const currentTheme = THEME_CONFIG[state.theme];

  // Dynamic CSS Generator based on View Mode
  const getSyntaxStyles = () => {
    if (state.displayOptions.showBlockView) {
        // Block View (Box Style)
        return `
          .subject { background-color: #ecfdf5; color: #047857; padding: 2px 4px; border-radius: 4px; font-weight: 600; border: 1px solid #6ee7b7; margin: 0 1px; display: inline-block; line-height: 1.2; }
          .verb { background-color: #fff1f2; color: #be123c; padding: 2px 4px; border-radius: 4px; font-weight: 700; border: 1px solid #fda4af; margin: 0 1px; display: inline-block; line-height: 1.2; }
          .object { background-color: #eff6ff; color: #1d4ed8; padding: 2px 4px; border-radius: 4px; font-weight: 600; border: 1px solid #93c5fd; margin: 0 1px; display: inline-block; line-height: 1.2; }
          .complement { background-color: #f5f3ff; color: #6d28d9; padding: 2px 4px; border-radius: 4px; font-weight: 600; border: 1px solid #c4b5fd; margin: 0 1px; display: inline-block; line-height: 1.2; }
          .modifier { background-color: #f8fafc; color: #475569; padding: 2px 4px; border-radius: 4px; border: 1px dashed #cbd5e1; margin: 0 1px; display: inline-block; line-height: 1.2; }
        `;
    } else {
        // Default Clean Underline Style
        return `
          .subject { color: #059669; border-bottom: 2px solid #059669; padding-bottom: 0px; font-weight: 600; }
          .verb { color: #be123c; border-bottom: 2px solid #be123c; padding-bottom: 0px; font-weight: 700; }
          .object { color: #2563eb; border-bottom: 2px solid #2563eb; padding-bottom: 0px; font-weight: 600; }
          .complement { color: #7c3aed; border-bottom: 2px solid #7c3aed; padding-bottom: 0px; font-weight: 600; }
          .modifier { color: #475569; border-bottom: 1.5px dashed #94a3b8; padding-bottom: 0px; }
        `;
    }
  };

  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault();
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
        setContextMenu({ visible: true, x: e.clientX, y: e.clientY });
    }
  };

  const applyFormat = (format: string) => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const range = selection.getRangeAt(0);
    const span = document.createElement('span');
    span.className = format;
    try { range.surroundContents(span); } catch (e) {}
    window.getSelection()?.removeAllRanges();
  };

  const downloadPDF = async () => {
    if (!printableRef.current) return;
    setIsGeneratingPdf(true);

    const element = printableRef.current;
    
    // Configuration for html2pdf
    // Scale 2 provides Retina-like quality
    // Margin aligns with the design padding
    // Pagebreak mode avoids cutting 'break-inside-avoid' elements
    const opt = {
      margin:       [10, 10, 10, 10], // top, left, bottom, right in mm
      filename:     `${state.questionId || 'Analysis_Material'}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true, scrollY: 0, logging: false },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] } 
    };

    try {
        await html2pdf().set(opt).from(element).save();
    } catch (err) {
        console.error("PDF generation failed:", err);
        alert("PDF 생성 중 오류가 발생했습니다.");
    } finally {
        setIsGeneratingPdf(false);
    }
  };

  const downloadHTML = () => {
    if (!printableRef.current) return;
    
    // Get the exact content
    const content = printableRef.current.innerHTML;
    
    // Construct a complete HTML file that mimics the app environment exactly
    const tailwindScript = `<script src="https://cdn.tailwindcss.com"></script>`;
    const fontLink = `<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">`;
    const baseStyle = `
        body { 
            font-family: 'Inter', 'Noto Sans KR', sans-serif; 
            background-color: #f1f5f9; /* Match app background */
            margin: 0;
            padding: 40px; /* Match app padding */
            display: flex;
            justify-content: center;
        }
    `;
    const syntaxStyle = getSyntaxStyles();
    
    // Wrap the content in a container that matches the "sheet" look (white, shadow, dimensions)
    const wrapper = `
        <div class="max-w-[210mm] w-full min-h-[297mm] bg-white text-slate-900 shadow-xl p-10 mx-auto">
            ${content}
        </div>
    `;

    const fullHtml = `<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${state.questionId || 'Material'}</title>
    ${tailwindScript}
    ${fontLink}
    <style>${baseStyle} ${syntaxStyle}</style>
</head>
<body>
    ${wrapper}
</body>
</html>`;

    const blob = new Blob([fullHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${state.questionId || 'material'}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getCircleNumber = (num: number) => {
      const circleMap = ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩', '⑪', '⑫', '⑬', '⑭', '⑮'];
      return circleMap[num - 1] || `(${num})`;
  };

  const renderStars = (count: number) => {
    return (
      <div className={`flex ${currentTheme.text}`}>
        {[...Array(count)].map((_, i) => <Star key={i} size={10} fill="currentColor" />)}
      </div>
    );
  };

  if (!state.result) {
    return (
      <div className="h-full flex items-center justify-center p-8 bg-slate-100">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 bg-white rounded-2xl mx-auto mb-8 flex items-center justify-center shadow-lg border border-slate-200">
            <FileText className="text-pink-400 w-12 h-12 opacity-80" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-4">시각화 미리보기</h2>
          <p className="text-slate-500 mb-8 leading-relaxed">지문을 입력하고 분석을 시작하세요.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-100 relative overflow-hidden">
        <style>{getSyntaxStyles()}</style>
        
        {/* Fixed Toolbar */}
        <div className="flex-none h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-50 shadow-sm no-print">
            <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-700">Preview</span>
                <span className="text-xs text-slate-400">| A4 Layout</span>
            </div>
            <div className="flex gap-2">
                <button 
                  onClick={downloadPDF} 
                  disabled={isGeneratingPdf}
                  className={`bg-white hover:bg-slate-50 text-rose-600 border border-slate-200 px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors shadow-sm ${isGeneratingPdf ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                    {isGeneratingPdf ? (
                        <span className="animate-spin text-xs">⏳</span> 
                    ) : (
                        <FileCheck size={14} />
                    )}
                    {isGeneratingPdf ? '생성 중...' : 'PDF 저장'}
                </button>
                <button onClick={downloadHTML} className="bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors shadow-sm">
                    <Download size={14} className={currentTheme.text}/> HTML 저장
                </button>
            </div>
        </div>

        {contextMenu.visible && (
            <div className="fixed bg-white border border-slate-200 shadow-xl rounded-lg py-1 z-50 w-48 overflow-hidden" style={{ top: contextMenu.y, left: contextMenu.x }}>
                <button onClick={() => applyFormat('subject')} className="w-full text-left px-4 py-2 text-sm text-emerald-600 hover:bg-emerald-50 font-bold border-b border-emerald-100">Subject (S)</button>
                <button onClick={() => applyFormat('verb')} className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 font-bold border-b border-rose-100">Verb (V)</button>
                <button onClick={() => applyFormat('object')} className="w-full text-left px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 font-bold border-b border-blue-100">Object (O)</button>
                <button onClick={() => applyFormat('complement')} className="w-full text-left px-4 py-2 text-sm text-violet-600 hover:bg-violet-50 font-bold border-b border-violet-100">Complement (C)</button>
                <button onClick={() => applyFormat('modifier')} className="w-full text-left px-4 py-2 text-sm text-slate-500 hover:bg-slate-50 italic">Modifier (M)</button>
            </div>
        )}

      {/* Scrollable Content Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 relative print:p-0 print:overflow-visible">
          <div ref={printableRef} id="printable-area" className="max-w-[210mm] mx-auto min-h-[297mm] bg-white text-slate-900 shadow-xl p-10 relative print:shadow-none print:w-full print:max-w-none print:min-h-0 print:p-0" onContextMenu={handleRightClick}>
            
            {/* Header */}
            <header className={`border-b-2 ${currentTheme.border} pb-4 mb-6 flex justify-between items-end`}>
                <div className="max-w-full">
                    {state.questionId && (
                        <div className={`text-2xl font-black ${currentTheme.text} mb-1 break-words leading-tight`}>
                            {state.questionId}
                        </div>
                    )}
                    <h1 className={`text-xl font-bold text-slate-800`}>{state.result.summary?.titleEn}</h1>
                    <h2 className="text-sm font-medium text-slate-500 mt-1">{state.result.summary?.titleKo}</h2>
                    {/* Keyword display removed here */}
                </div>
            </header>

            {/* Simplified Stats Row */}
            <div className="mb-6 flex flex-wrap items-center gap-4 text-xs">
                 <span className={`px-2 py-0.5 rounded-md font-bold uppercase tracking-wide text-white ${currentTheme.badge}`}> 
                    {state.result.stats.difficultyLevel} 
                 </span>

                 <div className="h-4 w-px bg-slate-300 mx-1"></div>

                 {/* Word Count */}
                 <span className="flex items-center gap-1.5 text-slate-500">
                    <FileText size={14} className="text-slate-400" />
                    {state.result.stats.wordCount} Words
                 </span>
                 
                 {/* Sentence Count */}
                 <span className="flex items-center gap-1.5 text-slate-500">
                     <AlignLeft size={14} className="text-slate-400" />
                     {state.result.stats.sentenceCount} Sentences
                 </span>
            </div>

            {/* Legend - Updates based on mode */}
            <div className="mb-8 flex flex-wrap gap-4 text-xs font-medium text-slate-500 bg-slate-50 p-2 rounded border border-slate-100 print:hidden">
                <span className="flex items-center gap-1"><span className={`w-6 h-4 flex items-center justify-center ${state.displayOptions.showBlockView ? 'bg-[#ecfdf5] border border-[#6ee7b7] rounded' : ''}`}><span className={`w-full h-0.5 ${state.displayOptions.showBlockView ? 'bg-transparent' : 'bg-emerald-600'}`}></span></span> Subject</span>
                <span className="flex items-center gap-1"><span className={`w-6 h-4 flex items-center justify-center ${state.displayOptions.showBlockView ? 'bg-[#fff1f2] border border-[#fda4af] rounded' : ''}`}><span className={`w-full h-0.5 ${state.displayOptions.showBlockView ? 'bg-transparent' : 'bg-rose-700'}`}></span></span> Verb</span>
                <span className="flex items-center gap-1"><span className={`w-6 h-4 flex items-center justify-center ${state.displayOptions.showBlockView ? 'bg-[#eff6ff] border border-[#93c5fd] rounded' : ''}`}><span className={`w-full h-0.5 ${state.displayOptions.showBlockView ? 'bg-transparent' : 'bg-blue-600'}`}></span></span> Object</span>
                <span className="flex items-center gap-1"><span className={`w-6 h-4 flex items-center justify-center ${state.displayOptions.showBlockView ? 'bg-[#f5f3ff] border border-[#c4b5fd] rounded' : ''}`}><span className={`w-full h-0.5 ${state.displayOptions.showBlockView ? 'bg-transparent' : 'bg-violet-600'}`}></span></span> Complement</span>
                <span className="flex items-center gap-1"><span className={`w-6 h-4 flex items-center justify-center ${state.displayOptions.showBlockView ? 'bg-[#f8fafc] border border-dashed border-[#cbd5e1] rounded' : ''}`}><span className={`w-full h-px border-t ${state.displayOptions.showBlockView ? 'border-transparent' : 'border-dashed border-slate-400'}`}></span></span> Modifier</span>
            </div>

            {/* Sentences Analysis */}
            <div className="space-y-4">
                {state.result.sentences?.map((sent, idx) => (
                    <div key={idx} className={`break-inside-avoid ${state.result?.examInsights?.mainSentenceIndex === idx && state.displayOptions.showExamInsights ? `ring-2 rounded-lg p-1 -m-1 ${currentTheme.border} bg-opacity-10` : ''}`}>
                         {state.result?.examInsights?.mainSentenceIndex === idx && state.displayOptions.showExamInsights && (
                            <div className={`text-[10px] ${currentTheme.text} font-bold uppercase mb-1 flex items-center gap-1 px-1`}>
                                <Star size={10} fill="currentColor" /> Main Idea
                            </div>
                         )}
                        <div className="flex gap-3">
                            <div className={`w-6 h-6 rounded flex-shrink-0 flex items-center justify-center font-bold text-xs mt-1 text-white ${currentTheme.badge}`}>
                                {idx + 1}
                            </div>
                            <div className="flex-1 border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                                
                                {/* 1. English Text */}
                                <div className="bg-white p-4">
                                    <div className={`text-lg leading-[2.2] font-sans font-medium text-slate-800 outline-none ${state.displayOptions.showBlockView ? 'leading-[2.8]' : ''}`} contentEditable suppressContentEditableWarning dangerouslySetInnerHTML={{ __html: sent.highlighted }} />
                                </div>

                                {/* 2. Translation */}
                                {state.displayOptions.showTranslation && (
                                    <div className="bg-slate-50 border-t border-slate-100 p-3 px-4 flex gap-2 items-start">
                                        <span className="text-[10px] font-bold text-slate-400 mt-0.5 shrink-0 uppercase tracking-wider">Meaning</span>
                                        <p className="text-slate-700 text-sm font-medium leading-relaxed">{sent.translation}</p>
                                    </div>
                                )}

                                {/* 3. Grammar Notes */}
                                {state.displayOptions.showGrammar && (sent.grammarNotes?.length || 0) > 0 && (
                                    <div className="bg-white border-t border-slate-100 p-3 px-4">
                                        <ul className="space-y-1">
                                            {sent.grammarNotes.map((note, nIdx) => (
                                                <li key={nIdx} className="text-xs text-slate-600 flex gap-2 items-start leading-snug">
                                                    <span className={`font-bold ${currentTheme.text}`}>{getCircleNumber(nIdx + 1)}</span>
                                                    <span>{note}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {state.displayOptions.showVocabulary && (
                <div className={`mt-10 pt-6 border-t-2 ${currentTheme.border} break-before-auto`}>
                    <h3 className={`text-lg font-bold ${currentTheme.text} mb-4 flex items-center gap-2`}><BookOpen size={20} /> Essential Vocabulary</h3>
                    <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                        {state.result.vocabulary?.map((vocab, idx) => (
                            <div key={idx} className="border-b border-slate-100 pb-2 break-inside-avoid">
                                <div className="flex justify-between items-baseline mb-1">
                                    <div className="flex items-baseline gap-2">
                                        <span className="font-bold text-slate-800 text-base">{vocab.word}</span>
                                        <span className="text-[10px] text-slate-400 uppercase">{vocab.partOfSpeech}</span>
                                    </div>
                                    <span className="text-slate-700 font-medium text-xs text-right">{vocab.meaning}</span>
                                </div>
                                {(vocab.synonyms && vocab.synonyms.length > 0 || vocab.antonyms && vocab.antonyms.length > 0) && (
                                    <div className="flex flex-col gap-1 mt-1">
                                        {vocab.synonyms && vocab.synonyms.length > 0 && (
                                            <div className="flex gap-2 items-baseline text-[10px]">
                                                <span className="text-slate-400 font-bold min-w-[20px] text-right">[=]</span>
                                                <div className="flex flex-wrap gap-1">
                                                    {vocab.synonyms.slice(0, 3).map((s, i) => (
                                                        <span key={i} className="text-slate-500 bg-slate-50 px-1 rounded">{s}</span>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                        {vocab.antonyms && vocab.antonyms.length > 0 && (
                                            <div className="flex gap-2 items-baseline text-[10px]">
                                                <span className="text-slate-400 font-bold min-w-[20px] text-right">[&lt;&gt;]</span>
                                                <div className="flex flex-wrap gap-1">
                                                    {vocab.antonyms.slice(0, 3).map((a, i) => (
                                                        <span key={i} className="text-slate-500 bg-slate-50 px-1 rounded">{a}</span>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {state.displayOptions.showSummary && (
                <div className={`mt-10 pt-6 border-t-2 ${currentTheme.border} break-before-auto`}>
                    <h3 className={`text-lg font-bold ${currentTheme.text} mb-4 flex items-center gap-2`}><ListOrdered size={20} /> Summary & Flow</h3>
                    <div className={`p-6 rounded-lg border ${currentTheme.border} ${currentTheme.bg}`}>
                        <div className="mb-6 text-center">
                             <span className="text-[10px] font-bold uppercase tracking-wider opacity-60 mb-1 block">Topic</span>
                             <p className="text-lg font-bold text-slate-800">{state.result.summary?.topic}</p>
                        </div>
                        
                        <div className="space-y-0">
                            {state.result.summary?.flow?.map((item, idx) => (
                                <div key={idx} className="flex flex-col items-center">
                                    <div className="w-full bg-white border border-slate-200 rounded p-3 shadow-sm text-slate-700 text-sm text-center leading-relaxed">
                                        {item}
                                    </div>
                                    {idx < (state.result.summary?.flow?.length || 0) - 1 && (
                                        <div className="h-6 flex items-center justify-center">
                                            <ArrowDown className={`${currentTheme.text} opacity-40`} size={16} />
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Exam Insights Section (Moved here & Themed) */}
            {state.displayOptions.showExamInsights && state.result.examInsights?.checkpoints && state.result.examInsights.checkpoints.length > 0 && (
                 <div className={`mt-10 pt-6 border-t-2 ${currentTheme.border} break-before-auto`}>
                    <h3 className={`text-lg font-bold ${currentTheme.text} mb-4 flex items-center gap-2`}><Lightbulb size={20} /> Exam Checkpoints</h3>
                    <div className={`${currentTheme.bg} rounded-lg border ${currentTheme.border} p-6 space-y-4`}>
                        {state.result.examInsights.checkpoints.map((point, idx) => (
                            <div key={idx} className="flex gap-3 items-start">
                                <div className={`mt-1 ${currentTheme.text} flex-shrink-0`}>
                                    <CheckCircle2 size={18} />
                                </div>
                                <div className="flex-1">
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="font-bold text-slate-800 text-sm">{point.point}</span>
                                        <span className={`text-[10px] bg-white border ${currentTheme.border} px-2 py-0.5 rounded ${currentTheme.text} font-bold uppercase`}>{point.type}</span>
                                    </div>
                                    <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">{point.explanation}</p>
                                    <div className="mt-1">
                                        {renderStars(point.importance)}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
          </div>
      </div>
    </div>
  );
};

export default PreviewPanel;