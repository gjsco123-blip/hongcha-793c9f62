import { GoogleGenAI, Type, GenerateContentParameters, ThinkingLevel } from "@google/genai";
import { AnalysisResult } from "../types";

const parseJSON = (text: string) => {
    try {
        let cleanText = text.replace(/```json/g, '').replace(/```/g, '').trim();
        const firstBrace = cleanText.indexOf('{');
        const lastBrace = cleanText.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace !== -1) {
            cleanText = cleanText.substring(firstBrace, lastBrace + 1);
        }
        return JSON.parse(cleanText);
    } catch (e) {
        console.error("JSON Parse Error:", e);
        return null;
    }
};

export const analyzeText = async (text: string, customApiKey: string): Promise<AnalysisResult> => {
  // 1. Trim the custom key to remove accidental whitespace (copy-paste issues)
  const trimmedCustomKey = customApiKey ? customApiKey.trim() : "";
  
  // 2. Prioritize custom key if present, otherwise fallback to env key
  const apiKey = trimmedCustomKey || process.env.API_KEY;

  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  // Debugging: Log the masked API key to console to verify it is being received correctly
  console.log(`[GeminiService] Using API Key: ${apiKey.slice(0, 5)}...${apiKey.slice(-4)}`);

  const ai = new GoogleGenAI({ apiKey: apiKey });

  const systemInstruction = `You are an elite English Education Specialist for Korean students, simulating the high standards of Daechidong institutes (Korea's top education district).
  Your goal is to analyze English text and produce structured study materials identical to high-quality Korean EFL textbooks (EBS Suneung Style).
  
  ### 1. INPUT PROCESSING & TRANSLATION
  - **Mixed Input**: The input may contain English text interleaved with Korean, or separated blocks.
  - **Separation**: Extract the full English text for analysis.
  - **Translation**: 
    - If Korean translation is provided, ALIGN it sentence-by-sentence with the English.
    - If NO Korean translation is provided, generate a fluent, academic-style Korean translation.

  ### 2. SYNTAX HIGHLIGHTING (CRITICAL)
  - Return the \`highlighted\` field as an HTML string.
  - **Tags**: Use ONLY \`<span class="class_name">content</span>\`.
  - **Classes**:
    - \`subject\`: Main Subject and important clause subjects.
    - \`verb\`: Main Verb and important clause verbs.
    - \`object\`: Objects (Direct/Indirect).
    - \`complement\`: Complements (Subject/Object).
    - \`modifier\`: Long modifiers, Prepositional phrases, Adverbial clauses, Relative clauses.
  - **Rules**:
    - Do NOT insert textual markers like '/', '()', '[]' into the text. Visuals will be handled by CSS.
    - Identify the *core* structure (Main Clause) clearly.
  
  ### 3. DEEP GRAMMAR & VOCABULARY (OUTPUT IN KOREAN)
  - **Grammar Notes**: Explain the *syntax function* and *grammar rules* applied **IN KOREAN**. (e.g., "to부정사의 부사적 용법(목적)", "목적격 관계대명사 생략").
  - **Vocabulary**: Extract CEFR B2/C1+ words. Provide the **contextual meaning IN KOREAN**.

  ### 4. EXAM INSIGHTS (CSAT SPECIALIZED - OUTPUT IN KOREAN)
  - **Goal**: Analyze the text from the perspective of a **CSAT (Suneung) Question Creator**.
  - **Checkpoints**: Identify 3-5 critical points that could be turned into exam questions (Blank Inference, Sentence Insertion, Ordering, Grammar).
  - **Logic & Structure**:
    - **Logic**: Identify flow shifts (However, Thus) suitable for [Sentence Insertion] or [Ordering].
    - **Paraphrasing**: Identify key concepts suitable for [Blank Inference].
  - **Explanation Format (POE Approach)**:
    For each checkpoint, the \`explanation\` field MUST be in **KOREAN** and structured as follows:
    "💡 [학생의 함정]: (Explain why students might misinterpret this or choose a wrong answer - e.g., confusion with similar words, complex syntax structure).
     🎯 [출제자의 의도]: (Explain the core concept being tested - e.g., understanding logical gaps, specific grammar exceptions)."

  ### 5. SUMMARY
  - **Topic**: Keep the main topic **IN ENGLISH**.
  - **Flow**: Summarize the logical flow of the text step-by-step **IN KOREAN** (기승전결).
  `;

  const prompt = `Analyze the following English text (and optional Korean translation):\n"""\n${text}\n"""\n\nEnsure strict adherence to the JSON schema. \n\nIMPORTANT: Grammar Notes, Vocabulary Meanings, Flow, and Exam Explanations MUST BE IN KOREAN.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: systemInstruction,
      responseMimeType: "application/json",
      thinkingConfig: {
        thinkingLevel: ThinkingLevel.MEDIUM,
      },
      responseSchema: {
          type: Type.OBJECT,
          properties: {
              sentences: {
                  type: Type.ARRAY,
                  items: {
                      type: Type.OBJECT,
                      properties: {
                          original: { type: Type.STRING },
                          translation: { type: Type.STRING },
                          grammarNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
                          highlighted: { type: Type.STRING }
                      }
                  }
              },
              vocabulary: {
                  type: Type.ARRAY,
                  items: {
                      type: Type.OBJECT,
                      properties: {
                          word: { type: Type.STRING },
                          meaning: { type: Type.STRING },
                          partOfSpeech: { type: Type.STRING },
                          synonyms: { type: Type.ARRAY, items: { type: Type.STRING } },
                          antonyms: { type: Type.ARRAY, items: { type: Type.STRING } }
                      }
                  }
              },
              summary: {
                  type: Type.OBJECT,
                  properties: {
                      topic: { type: Type.STRING },
                      titleEn: { type: Type.STRING },
                      titleKo: { type: Type.STRING },
                      flow: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
              },
              examInsights: {
                  type: Type.OBJECT,
                  properties: {
                      keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                      mainSentenceIndex: { type: Type.INTEGER, description: "Index of the most important sentence (0-based)" },
                      checkpoints: {
                          type: Type.ARRAY,
                          items: {
                              type: Type.OBJECT,
                              properties: {
                                  type: { type: Type.STRING, enum: ['Grammar', 'Vocabulary', 'Logic', 'Content'] },
                                  point: { type: Type.STRING, description: "Short title of the point (in Korean)" },
                                  explanation: { type: Type.STRING, description: "Detailed Korean explanation with Trap and Intent" },
                                  importance: { type: Type.INTEGER, description: "1 to 5" }
                              }
                          }
                      }
                  }
              },
              stats: {
                  type: Type.OBJECT,
                  properties: {
                      wordCount: { type: Type.NUMBER },
                      sentenceCount: { type: Type.NUMBER },
                      difficultyLevel: { type: Type.STRING, enum: ["Beginner", "Intermediate", "Advanced"] }
                  }
              }
          }
      }
    }
  });

  const rawResult = parseJSON(response.text);
  if (!rawResult) throw new Error("Failed to parse API response");

  return {
    sentences: Array.isArray(rawResult.sentences) ? rawResult.sentences.map((s: any) => ({
        original: s.original || "",
        translation: s.translation || "",
        highlighted: s.highlighted || s.original || "",
        grammarNotes: Array.isArray(s.grammarNotes) ? s.grammarNotes : []
    })) : [],
    vocabulary: Array.isArray(rawResult.vocabulary) ? rawResult.vocabulary : [],
    summary: rawResult.summary || { topic: "No summary", titleEn: "Analysis", titleKo: "분석", flow: [] },
    examInsights: rawResult.examInsights || { keywords: [], mainSentenceIndex: -1, checkpoints: [] },
    stats: rawResult.stats || { wordCount: 0, sentenceCount: 0, difficultyLevel: 'Intermediate' }
  };
};